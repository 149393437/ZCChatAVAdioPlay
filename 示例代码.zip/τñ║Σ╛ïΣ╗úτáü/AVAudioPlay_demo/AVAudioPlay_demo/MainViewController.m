//
//  MainViewController.m
//  AVAudioPlay_demo
//
//  Created by ZhangCheng on 14-4-8.
//  Copyright (c) 2014年 zhangcheng. All rights reserved.
//

#import "MainViewController.h"
#import "ZCChatAVAdioPlay.h"
@interface MainViewController ()

@end

@implementation MainViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
//    UIButton*button=[UIButton buttonWithType:UIButtonTypeContactAdd];
//    button.backgroundColor=[UIColor redColor];
//    [self.view addSubview:button];
//    button.frame=CGRectMake(100, 100, 100, 100);
//   // [button addTarget:self action:@selector(buttonClick) forControlEvents:UIControlEventTouchUpInside];
//    [button addTarget:self action:@selector(aa1) forControlEvents:UIControlEventTouchDown];
//    
//    [button addTarget:self action:@selector(aa2) forControlEvents:UIControlEventTouchUpInside];
    
    
    UIView*view1=[[UIView alloc]initWithFrame:CGRectMake(100, 100, 100, 100)];
    view1.backgroundColor=[UIColor redColor];
    [self.view addSubview:view1];
    [view1 release];
    
    
    UILongPressGestureRecognizer*longPress=[[UILongPressGestureRecognizer alloc]initWithTarget:self action:@selector(aa1:)];
    [view1 addGestureRecognizer:longPress];
}
-(void)aa1:(UILongPressGestureRecognizer*)longPress{
    if (longPress.state==UIGestureRecognizerStateBegan) {
        NSLog(@"按下");
    }else{
        if (longPress.state==UIGestureRecognizerStateEnded) {
            NSLog(@"抬起");
        }
    }
    
   // NSLog(@"按下");

}
//-(void)aa2{
//    NSLog(@"抬起");
//}
-(void)buttonClick{
    NSArray*file=[ZCChatAVAdioPlay getVoiceFileName];
    NSLog(@"获取文件夹下目录%@",file);
    //读取出amr文件名
    NSString*last=[file objectAtIndex:file.count-2];
    //拼接路径
    NSString*path=[NSString stringWithFormat:@"%@/Library/Caches/Voice/%@",NSHomeDirectory(),last];
    NSLog(@"Main~%@",path);
    //读取文件
    NSData*data=[NSData dataWithContentsOfFile:path];
    ZCChatAVAdioPlay*av=[ZCChatAVAdioPlay sharedInstance];
    //播放
    [av playSetAvAudio:data];


}

-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
//    ZCChatAVAdioPlay*avAdio=[ZCChatAVAdioPlay sharedInstance];
//    [avAdio startRecording];
//    [self performSelector:@selector(end1) withObject:nil afterDelay:5];
    
    
}
-(void)end1
{
 ZCChatAVAdioPlay*avAdio=[ZCChatAVAdioPlay sharedInstance];
    [avAdio endRecordingWithBlock:^(NSString *aa) {
        
        NSLog(@"amr转码base64，可以进行发送数据%@",aa);
        
    }];
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
   
}



@end
